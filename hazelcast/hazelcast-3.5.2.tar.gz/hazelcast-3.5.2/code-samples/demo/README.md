## Hazelcast Demo Project

### Prerequisites

* Download code-samples zip file (3.3 releases or later) from https://github.com/hazelcast/hazelcast-code-samples/releases or http://hazelcast.org/download/
* unzip it to your local disk
* install maven project

```
mvn install
```
* go to script directory

```
cd demo/bin
```
* list available scripts

```
ls -lrt
```






