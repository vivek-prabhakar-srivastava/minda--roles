name             'hazelcast-integration-amazon-ec2'
maintainer       'David Brimley'
maintainer_email 'david@hazelcast.com'
license          'Apache License, Version 2.0'
description      'Installs/Configures hazelcast-integration-amazon-ec2'
long_description 'Installs/Configures hazelcast-integration-amazon-ec2'
version          '0.1.0'

depends "java"
