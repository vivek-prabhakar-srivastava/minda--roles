import java.util.ArrayList;

public class ExtendedArrayList  extends ArrayList<Car> {
    @Override
    public String toString() {
        return "ExtendedArrayList{size=" + size() + "}";
    }
}
