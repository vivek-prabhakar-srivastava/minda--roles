public class PortableFactoryConstants {

    public final static int PERSON_FACTORY_ID = 1;
}
